
package com.learn.happytummy.ForgetPassword;

import com.learn.happytummy.dao.UserDao;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.helper.FactoryProvider;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;


public class checkUserEmail {
    
     
    private SessionFactory factory;
    public checkUserEmail(SessionFactory factory){
    this.factory=factory;
}
    public static boolean validateUserEmail(String email)
    {
        boolean status = false;
        
       UserDao userdao = new UserDao(FactoryProvider.getFactory());
      User user =     userdao.getUserbyEmail(email);
                
            {
                if (user==null)
                {
                    System.out.println("wrong email");
                    
                }
                else{
                    System.out.println(email);
                    System.out.println(user);
                    status= true;
                }
                
            }
        return status;
                
 
     
         
   
    } 
}
