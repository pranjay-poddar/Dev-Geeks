/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.Product;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.entities.orders;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 *
 * @author Aayush
 */
public class ordersDao {

    private SessionFactory factory;

    public ordersDao(SessionFactory factory) {
        this.factory = factory;
    }

    public boolean saveOrders(orders Orders) {

        boolean f = false;
        try {

            Session openSession = this.factory.openSession();
            Transaction tx = openSession.beginTransaction();

            openSession.save(Orders);

            tx.commit();
            openSession.close();
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
            f = false;
        }
        return f;
    }

    public List<orders> getlistofOrders() {
        Session s = this.factory.openSession();
        Query q = s.createQuery("from orders");
        List<orders> list = q.list();
        return list;
    }

    public List<orders> getlistofOrdersForId2(int id) {

        orders order = null;
        String query = "from orders where orderUserId =:e";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
        q.setParameter("e", id);

        List<orders> list = q.list();

        session.close();

        return list;

    }
  
     public orders getlistofOrdersForId(int id)
    {
       orders user=null;
             String query ="from orders where orderUserId =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e",id);
      
      user=(orders) q.uniqueResult();
      
      session.close();
        
        return user;
    }
     public orders getOrdersForId(int id)
    {
       orders user=null;
             String query ="from orders where OrderId =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e",id);
      
      user=(orders) q.uniqueResult();
      
      session.close();
        
        return user;
    }
     
     
     public List<orders> getListOfOrdRes(String restid)
     {
         String query ="from orders where orderRestaurantId =:e";
         
          Session session = this.factory.openSession();
        Query q = session.createQuery(query);
        q.setParameter("e", restid);

        List<orders> list = q.list();

        session.close();

        return list;
         
     }
     public List<orders> getListOfTiffinOrd()
     {
         String query ="from orders  where orderType= :e";
         
          Session session = this.factory.openSession();
        Query q = session.createQuery(query);
                q.setParameter("e", "tiffin");


        List<orders> list = q.list();

        session.close();

        return list;
         
     }
     public List<orders> getlistofOrderforHt()
     {
         String query ="from orders where orderRestaurantId =:e";
         
          Session session = this.factory.openSession();
        Query q = session.createQuery(query);
        q.setParameter("e", "HT");

        List<orders> list = q.list();

        session.close();

        return list;
         
     }

}
