package com.learn.happytummy.Servlets;

import com.learn.happytummy.ForgetPassword.checkUserEmail;
import com.learn.happytummy.dao.UserDao2;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.helper.FactoryProvider;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;

public class RegisterServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                HttpSession httpsession = request.getSession();
                String userName = request.getParameter("user_name");
                httpsession.setAttribute("userName", userName);

                String userEmail = request.getParameter("user_email");
                httpsession.setAttribute("userEmail", userEmail);
                String userPhone = request.getParameter("user_phone");
                httpsession.setAttribute("userPhone", userPhone);
                String userPass = request.getParameter("user_pass");
                httpsession.setAttribute("userPass", userPass);

                String userAddress = request.getParameter("user_address");
                httpsession.setAttribute("userAddress", userAddress);
                String userType = request.getParameter("user_type");
                httpsession.setAttribute("userType", userType);

//               String userStatus = request.getParameter("user_status");
//            validation
// checking if account exixts with same email
                try {
                    UserDao2 userdao = new UserDao2(FactoryProvider.getFactory());

                    User user2 = userdao.getUserbyEmailandPassword(userEmail);
//  User user2= userdao.getUserbyEmailandPassword(userEmail);
//           System.out.println(user);

                   
                    if (user2 == null) {
                        try {

                            int randomPin = (int) (Math.random() * 900000) + 100000;
                            String otp = String.valueOf(randomPin);

                            HttpSession session2 = request.getSession();
                            session2.setAttribute("otp", otp);
                            session2.setAttribute("email", userEmail);

                            final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
                            // Get a Properties object    
                            Properties props = System.getProperties();
                            props.setProperty("mail.smtp.host", "smtp.gmail.com");
                            props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
                            props.setProperty("mail.smtp.socketFactory.fallback", "false");
                            props.setProperty("mail.smtp.port", "465");
                            props.setProperty("mail.smtp.socketFactory.port", "465");
                            props.put("mail.smtp.auth", "true");
                            props.put("mail.debug", "true");
                            props.put("mail.store.protocol", "pop3");
                            props.put("mail.transport.protocol", "smtp");

                            javax.mail.Session session = javax.mail.Session.getInstance(props, new Authenticator() {

                                @Override
                                protected PasswordAuthentication getPasswordAuthentication() {
                                    return new PasswordAuthentication("happytummyjaora@gmail.com", "htPass@123");
                                }
                            });

                            // -- Create a new message --
                            Message msg = new MimeMessage(session);

                            // -- Set the FROM and TO fields --
                            msg.setFrom(new InternetAddress("happytummyjaora@gmail.com"));
                            msg.setRecipients(Message.RecipientType.TO,
                                    InternetAddress.parse(userEmail, false));
                            msg.setSubject("Happy Tummy Jaora");
                            msg.setText("Hi, " + userEmail + "\n Verify Account By entering these  "
                                    + " OTP: " + otp);
                            session2.setAttribute("message", "OTP Send");

//        RequestDispatcher rd=request.getRequestDispatcher("verifyEmailAddress.jsp");  
//        
//        rd.forward(request,response);  
                            response.sendRedirect("verifyEmailAddress.jsp");

                            msg.setSentDate(new Date());

                            Transport.send(msg);

//                 
// RequestDispatcher rd1=request.getRequestDispatcher("verifyEmailAddress.jsp");  
//        
//        rd1.forward(request,response); 
                        } catch (Exception e) {
                        }

                        return;
                    }

                
                else {
                    
                        
                 httpsession.setAttribute("message","Account Already Exists. Try Logging!!");
                  response.sendRedirect("login_page.jsp");
                }

            } catch (Exception e) {
            }

//             creating object to store data            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
/**
 * Handles the HTTP <code>GET</code> method.
 *
 * @param request servlet request
 * @param response servlet response
 * @throws ServletException if a servlet-specific error occurs
 * @throws IOException if an I/O error occurs
 */
@Override
        protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
        protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
        public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
