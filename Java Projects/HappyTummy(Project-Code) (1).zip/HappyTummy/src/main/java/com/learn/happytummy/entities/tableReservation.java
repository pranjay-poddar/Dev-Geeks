/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Aayush
 */
@Entity

public class tableReservation {
            @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int tableReservationID;
    private String userName;
    private String date;
    private int resid;
    private String people;
    private String Status;

    public tableReservation() {
    }

    public tableReservation(String userName, String date, int resid, String people, String Status) {
        this.userName = userName;
        this.date = date;
        this.resid = resid;
        this.people = people;
        this.Status = Status;
    }

    public String getStatus() {
        return Status;
    }

    public void setStatus(String Status) {
        this.Status = Status;
    }



    public int getTableReservationID() {
        return tableReservationID;
    }

    public void setTableReservationID(int tableReservationID) {
        this.tableReservationID = tableReservationID;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getResid() {
        return resid;
    }

    public void setResid(int resid) {
        this.resid = resid;
    }

    public String getPeople() {
        return people;
    }

    public void setPeople(String people) {
        this.people = people;
    }
    
}
