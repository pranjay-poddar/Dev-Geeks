/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.Product;
import com.learn.happytummy.entities.vegetables;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 *
 * @author Aayush
 */
public class vegetableDao {
       private SessionFactory factory;

     public vegetableDao(SessionFactory factory) {
        this.factory = factory;
    }
      public boolean savevegetables(vegetables veg) {

        boolean f = false;
        try {

            Session openSession = this.factory.openSession();
            Transaction tx = openSession.beginTransaction();

            openSession.save(veg);

            tx.commit();
            openSession.close();
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
            f = false;
        }
        return f;
    }
       public List<vegetables> getlistoflikevegetables(String name)
        {
            
//             Query query = session.createQuery("FROM Student WHERE studentName like concat('%',:studentName,'%')");
//        query.setParameter("studentName", likeStudentName);
        
            String query ="from vegetables where vName like concat('%',:e,'%')";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
               

      q.setParameter("e",name);
      
        List<vegetables> listres = q.list();
        return listres;
        }
      
      public List<vegetables> getAllVegetables() {

        Session S = this.factory.openSession();
        
       
        Query qurery = S.createQuery("from vegetables");
       
        List<vegetables> list = qurery.list();
       
        return list;

    }
       public vegetables getvegetableById(int vegId)
{  vegetables res =null;
    try{
        Session session = this.factory.openSession();
       res =session.get(vegetables.class, vegId);
       session.close();
    }
    catch(Exception e){
        e.printStackTrace();
    }
    return res;
}
}
