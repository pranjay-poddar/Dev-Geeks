/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Aayush
 */
@Entity
public class charityFoodInfo {
    
      @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
     private int donationId;
      public String donorName;
      public String pickUpAddress;
      public String quantityInfo;
      public int donorNumber;
      public String status;

    public charityFoodInfo() {
    }

    public charityFoodInfo(String donorName, String pickUpAddress, String quantityInfo, int donorNumber, String status) {
        this.donorName = donorName;
        this.pickUpAddress = pickUpAddress;
        this.quantityInfo = quantityInfo;
        this.donorNumber = donorNumber;
        this.status = status;
    }

    public charityFoodInfo(String donorName, String pickUpAddress, String quantityInfo, int donorNumber) {
        this.donorName = donorName;
        this.pickUpAddress = pickUpAddress;
        this.quantityInfo = quantityInfo;
        this.donorNumber = donorNumber;
    }
    

    public charityFoodInfo(int donationId, String donorName, String pickUpAddress, String quantityInfo, int donorNumber, String status) {
        this.donationId = donationId;
        this.donorName = donorName;
        this.pickUpAddress = pickUpAddress;
        this.quantityInfo = quantityInfo;
        this.donorNumber = donorNumber;
        this.status = status;
    }

  

    public charityFoodInfo(String status) {
        this.status = status;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    
    
    public int getDonationId() {
        return donationId;
    }

    public void setDonationId(int donationId) {
        this.donationId = donationId;
    }

    public String getDonorName() {
        return donorName;
    }

    public void setDonorName(String donorName) {
        this.donorName = donorName;
    }

    public String getPickUpAddress() {
        return pickUpAddress;
    }

    public void setPickUpAddress(String pickUpAddress) {
        this.pickUpAddress = pickUpAddress;
    }

    public String getQuantityInfo() {
        return quantityInfo;
    }

    public void setQuantityInfo(String quantityInfo) {
        this.quantityInfo = quantityInfo;
    }

    public int getDonorNumber() {
        return donorNumber;
    }

    public void setDonorNumber(int donorNumber) {
        this.donorNumber = donorNumber;
    }

   
    @Override
    public String toString() {
        return "charityFoodInfo{" + "donationId=" + donationId + ", donorName=" + donorName + ", pickUpAddress=" + pickUpAddress + ", quantityInfo=" + quantityInfo + ", donorNumber=" + donorNumber + '}';
    }
      
      
      
     
    
}
