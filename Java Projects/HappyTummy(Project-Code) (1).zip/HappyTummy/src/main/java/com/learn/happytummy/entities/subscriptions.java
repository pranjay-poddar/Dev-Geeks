/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


package com.learn.happytummy.entities;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class subscriptions {
      @Id
       @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int subscriptionnId;
     private String subscriptionType;
     private String subscriptionTiffinType;
     private String subscriberName;
     private String subscriptionStatus;
     private String subscriptionDate;
     private String subscriptionValidityDate;
     private String subscriptionAddress;
     private int subscriberUserid;

    public subscriptions(String subscriptionType, String subscriptionTiffinType, String subscriberName, String subscriptionStatus, String subscriptionDate, String subscriptionValidityDate, String subscriptionAddress, int subscriberUserid) {
        this.subscriptionType = subscriptionType;
        this.subscriptionTiffinType = subscriptionTiffinType;
        this.subscriberName = subscriberName;
        this.subscriptionStatus = subscriptionStatus;
        this.subscriptionDate = subscriptionDate;
        this.subscriptionValidityDate = subscriptionValidityDate;
        this.subscriptionAddress = subscriptionAddress;
        this.subscriberUserid = subscriberUserid;
    }

  

  



    public subscriptions() {
    }

    public int getSubscriptionnId() {
        return subscriptionnId;
    }

    public void setSubscriptionnId(int subscriptionnId) {
        this.subscriptionnId = subscriptionnId;
    }

    public String getSubscriptionType() {
        return subscriptionType;
    }

    public void setSubscriptionType(String subscriptionType) {
        this.subscriptionType = subscriptionType;
    }

    public String getsubscriberName() {
        return subscriberName;
    }

    public void setsubscriberName(String subscriberName) {
        this.subscriberName = subscriberName;
    }

    public String getSubscriptionStatus() {
        return subscriptionStatus;
    }

    public String getSubscriptionTiffinType() {
        return subscriptionTiffinType;
    }

    public void setSubscriptionTiffinType(String subscriptionTiffinType) {
        this.subscriptionTiffinType = subscriptionTiffinType;
    }

    public void setSubscriptionStatus(String subscriptionStatus) {
        this.subscriptionStatus = subscriptionStatus;
    }

    public String getSubscriptionDate() {
        return subscriptionDate;
    }

    public void setSubscriptionDate(String subscriptionDate) {
        this.subscriptionDate = subscriptionDate;
    }

    public String getSubscriptionValidityDate() {
        return subscriptionValidityDate;
    }

    public void setSubscriptionValidityDate(String subscriptionValidityDate) {
        this.subscriptionValidityDate = subscriptionValidityDate;
    }

    public String getSubscriptionAddress() {
        return subscriptionAddress;
    }

    public void setSubscriptionAddress(String subscriptionAddress) {
        this.subscriptionAddress = subscriptionAddress;
    }

    public String getSubscriberName() {
        return subscriberName;
    }

    public void setSubscriberName(String subscriberName) {
        this.subscriberName = subscriberName;
    }

    public int getSubscriberUserid() {
        return subscriberUserid;
    }

    public void setSubscriberUserid(int subscriberUserid) {
        this.subscriberUserid = subscriberUserid;
    }
     
     
}

