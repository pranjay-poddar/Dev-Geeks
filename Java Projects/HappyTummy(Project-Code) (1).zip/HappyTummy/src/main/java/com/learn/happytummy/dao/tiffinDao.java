/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.grocery;
import com.learn.happytummy.entities.tiffin;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 *
 * @author Aayush
 */
public class tiffinDao {
    private SessionFactory factory;

     public tiffinDao(SessionFactory factory) {
        this.factory = factory;
    }

    public boolean savetiffin(tiffin tiffins) {

        boolean f = false;
        try {

            Session openSession = this.factory.openSession();
            Transaction tx = openSession.beginTransaction();

            openSession.save(tiffins);

            tx.commit();
            openSession.close();
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
            f = false;
        }
        return f;
    }
    
      public List<tiffin> getAlltiffin() {

        Session S = this.factory.openSession();
        
       
        Query qurery = S.createQuery("from tiffin");
       
        List<tiffin> list = qurery.list();
       
        return list;

    }
       public List<tiffin> getlistofliketiffin(String name)
        {
            
//             Query query = session.createQuery("FROM Student WHERE studentName like concat('%',:studentName,'%')");
//        query.setParameter("studentName", likeStudentName);
        
            String query ="from tiffin where tTitle like concat('%',:e,'%')";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
               

      q.setParameter("e",name);
      
        List<tiffin> listres = q.list();
        return listres;
        }
      
     
     public List<tiffin> getlistoftiffinforResId(int id)
     {
         String query ="from tiffin where restaurantID_restaurantId =:e";
         
          Session session = this.factory.openSession();
        Query q = session.createQuery(query);
        q.setParameter("e", id);

        List<tiffin> list = q.list();

        session.close();

        return list;
         
     }
      public tiffin gettiffinById(int tId)
{  tiffin res =null;
    try{
        Session session = this.factory.openSession();
       res =session.get(tiffin.class, tId);
       session.close();
    }
    catch(Exception e){
        e.printStackTrace();
    }
    return res;
}
}
