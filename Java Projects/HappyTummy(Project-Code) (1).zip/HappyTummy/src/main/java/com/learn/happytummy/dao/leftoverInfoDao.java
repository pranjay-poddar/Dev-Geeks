/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.charityFoodInfo;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 *
 * @author Aayush
 */
public class leftoverInfoDao {

    private SessionFactory factory;

    public leftoverInfoDao(SessionFactory factory) {
        this.factory = factory;
    }

    public int saveDetails(charityFoodInfo info) {

        Session openSession = this.factory.openSession();
        Transaction tx = openSession.beginTransaction();
        int charityId = (int) openSession.save(info);
        tx.commit();
        openSession.close();
        return charityId;
    }
    
     public charityFoodInfo getdeatilById(int id)
    {
       charityFoodInfo user=null;
             String query ="from charityFoodInfo where donationId =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e",id);
      
      user=(charityFoodInfo) q.uniqueResult();
      
      session.close();
        
        return user;
    }
//
//    public int changeStatus(charityFoodInfo info) {
//        
//        Session session = this.factory.openSession();
//        session.getTransaction().begin();
//        Query query = session.createSQLQuery(
//                "update charityFoodInfo set status = :docname" + " where Id = :Id");
//        query.setParameter("status", "picked");
//        query.setParameter("Id", info);
//        int result = query.executeUpdate();
//        session.getTransaction().commit();
//        return result;
//    }

    public List<charityFoodInfo> getlist() {
        Session s = this.factory.openSession();
        Query q = s.createQuery("from charityFoodInfo");
        List<charityFoodInfo> list = q.list();
        return list;
    }
}
