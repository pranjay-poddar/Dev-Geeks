
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.Queries;
import com.learn.happytummy.entities.charityFoodInfo;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;


public class queryDao {
      private SessionFactory factory;
    public queryDao(SessionFactory factory){
    this.factory=factory;
}
 
    public int saveQuery(Queries queries)
    {
        
         Session openSession = this.factory.openSession();
       Transaction tx= openSession.beginTransaction();
        int queId=(int)openSession.save(queries);
       tx.commit();
       openSession.close();
       return queId ;
    }
     public List<Queries> getlistof() {
        Session s = this.factory.openSession();
        Query q = s.createQuery("from Queries");
        List<Queries> list = q.list();
        return list;
    }
}
