/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.Product;
import com.learn.happytummy.entities.grocery;
import com.learn.happytummy.entities.vegetables;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

/**
 *
 * @author Aayush
 */
public class groceryDao {
        private SessionFactory factory;

     public groceryDao(SessionFactory factory) {
        this.factory = factory;
    }

    public boolean saveGrocery(grocery Grocery) {

        boolean f = false;
        try {

            Session openSession = this.factory.openSession();
            Transaction tx = openSession.beginTransaction();

            openSession.save(Grocery);

            tx.commit();
            openSession.close();
            f = true;
        } catch (Exception e) {
            e.printStackTrace();
            f = false;
        }
        return f;
    }
    
    
     public List<grocery> getlistoflikegrocery(String name)
        {
            
//             Query query = session.createQuery("FROM Student WHERE studentName like concat('%',:studentName,'%')");
//        query.setParameter("studentName", likeStudentName);
        
            String query ="from grocery where gName like concat('%',:e,'%')";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
               

      q.setParameter("e",name);
      
        List<grocery> listres = q.list();
        return listres;
        }
    
     public List<grocery> getAllgrocery() {

        Session S = this.factory.openSession();
        
       
        Query qurery = S.createQuery("from grocery");
       
        List<grocery> list = qurery.list();
       
        return list;

    }
      public grocery getgroceryById(int groId)
{  grocery res =null;
    try{
        Session session = this.factory.openSession();
       res =session.get(grocery.class, groId);
       session.close();
    }
    catch(Exception e){
        e.printStackTrace();
    }
    return res;
}
}
