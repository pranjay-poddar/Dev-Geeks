/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.subscriptions;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

/**
 *
 * @author Aayush
 */
public class subscriptionDao {
      private SessionFactory factory;
    public subscriptionDao(SessionFactory factory){
    this.factory=factory;
    }
    
    public List<subscriptions> getpendingsubscription()
    {
             String query ="from subscriptions where subscriptionStatus =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e","request");
      
        List<subscriptions> list = q.list();
      
      session.close();
        
        return  list;
    }
    public List<subscriptions> getoversubscription()
    {
             String query ="from subscriptions where subscriptionStatus =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e","over");
      
        List<subscriptions> list = q.list();
      
      session.close();
        
        return  list;
    }
    public List<subscriptions> getactivesubscription()
    {
             String query ="from subscriptions where subscriptionStatus =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e","active");
      
        List<subscriptions> list = q.list();
      
      session.close();
        
        return  list;
    }
    
     public subscriptions getsubscriptionsForId(int id)
    {
       subscriptions user=null;
             String query ="from subscriptions where subscriptionnId =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e",id);
      
      user=(subscriptions) q.uniqueResult();
      
      session.close();
        
        return user;
    }
       public List<subscriptions> getactivesubscriptionforid(int id)
    {
             String query ="from subscriptions where subscriberUserid =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e",id);
      
        List<subscriptions> list = q.list();
      
      session.close();
        
        return  list;
    }
    
}
    

