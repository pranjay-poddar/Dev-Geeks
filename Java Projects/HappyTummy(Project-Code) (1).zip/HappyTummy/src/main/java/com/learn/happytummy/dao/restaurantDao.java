
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.Restaurant;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;


public class restaurantDao {
    
    
    private SessionFactory factory;

    public restaurantDao(SessionFactory factory) {
        this.factory = factory;
    }
    
    
    public int saveRestaurant(Restaurant res)
    {
        
       Session openSession = this.factory.openSession();
       Transaction tx= openSession.beginTransaction();
        int resId=(int)openSession.save(res);
       tx.commit();
       openSession.close();
       return resId ;
    }
     public List<Restaurant> getlistofActiveRestaurant()
        {
            String query ="from Restaurant where restaurantStatus= :e";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
               

      q.setParameter("e","active");
      
        List<Restaurant> listres = q.list();
        return listres;
        }
     public List<Restaurant> getlistoflikeRestaurant(String name)
        {
            
//             Query query = session.createQuery("FROM Student WHERE studentName like concat('%',:studentName,'%')");
//        query.setParameter("studentName", likeStudentName);
        
            String query ="from Restaurant where restaurantTitle like concat('%',:e,'%')";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
               

      q.setParameter("e",name);
      
        List<Restaurant> listres = q.list();
        return listres;
        }
    
    
    public List<Restaurant> getRestaurants(){
    Session s = this.factory.openSession();
    Query q = s.createQuery("from Restaurant");
    List<Restaurant> list =q.list();
    return list;
}
    public Restaurant getRestaurantbyEmailID(String email){
        Restaurant resta = null;
          String query ="from Restaurant where restaurantEmail =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e", email);
             
      
      
            resta=(Restaurant) q.uniqueResult();
session.close();
        return resta;
        
        
    }
    public Restaurant getRestaurantbyID(int id){
        Restaurant resta = null;
          String query ="from Restaurant where restaurantId =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e", id);
             
      
      
            resta=(Restaurant) q.uniqueResult();
session.close();
        return resta;
        
        
    
    }
    public Restaurant getRestaurantbyIDObject(Restaurant id){
        Restaurant resta1 = null;
          String query ="from Restaurant where restaurantId =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e", id);
             
      
      
            resta1=(Restaurant) q.uniqueResult();
session.close();
        return resta1;
        
        
    }
    
    public Restaurant getRestaurantById(int resId)
{  Restaurant res =null;
    try{
        Session session = this.factory.openSession();
       res =session.get(Restaurant.class, resId);
       session.close();
    }
    catch(Exception e){
        e.printStackTrace();
    }
    return res;
}
       public Restaurant getRestaurantByEmail(String resEmail)
{  Restaurant res =null;
    try{
        Session session = this.factory.openSession();
       res =session.get(Restaurant.class, resEmail);
       session.close();
    }
    catch(Exception e){
        e.printStackTrace();
    }
    return res;
}
    
    
    
     public List<Restaurant> getlistofRestaurant()
        {
        Session s = this.factory.openSession();
        Query q = s.createQuery("from Restaurant");
        List<Restaurant> listres = q.list();
        return listres;
        }
     public List<Restaurant> getlistofinActiveRestaurant()
        {
            String query ="from Restaurant where restaurantStatus= :e";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
               

      q.setParameter("e","inactive");
      
        List<Restaurant> listres = q.list();
        return listres;
        }
     
    
      public List<Restaurant> getlistofRestaurantById(int id) {

        Restaurant order = null;
        String query = "from Restaurant where restaurantId =:e";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
        q.setParameter("e", id);

        List<Restaurant> list = q.list();

        session.close();

        return list;

    }
     
}
