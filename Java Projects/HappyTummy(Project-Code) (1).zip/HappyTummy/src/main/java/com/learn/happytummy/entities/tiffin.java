/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

/**
 *
 * @author Aayush
 */
@Entity
public class tiffin {
       @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int tiId;
    private String tTitle;
    private String tPhoto;
    private int tPrice;
    private String tDescription;
    
   

    public tiffin() {
    }

    public tiffin(String tTitle, String tPhoto, int tPrice, String tDescription) {
        this.tTitle = tTitle;
        this.tPhoto = tPhoto;
        this.tPrice = tPrice;
        this.tDescription = tDescription;
    }

    public int getTiId() {
        return tiId;
    }

    public void setTiId(int tiId) {
        this.tiId = tiId;
    }

    public String gettTitle() {
        return tTitle;
    }

    public void settTitle(String tTitle) {
        this.tTitle = tTitle;
    }

    public String gettPhoto() {
        return tPhoto;
    }

    public void settPhoto(String tPhoto) {
        this.tPhoto = tPhoto;
    }

    public int gettPrice() {
        return tPrice;
    }

    public void settPrice(int tPrice) {
        this.tPrice = tPrice;
    }

    public String gettDescription() {
        return tDescription;
    }

    public void settDescription(String tDescription) {
        this.tDescription = tDescription;
    }

  
        
}
