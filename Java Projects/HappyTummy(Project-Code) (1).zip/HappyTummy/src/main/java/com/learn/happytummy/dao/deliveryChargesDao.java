/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.Restaurant;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.entities.deliveryCharges;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;


public class deliveryChargesDao {
     private SessionFactory factory;
    public deliveryChargesDao(SessionFactory factory){
    this.factory=factory;
}
     public int saveCharges(deliveryCharges del)
    {
        int r = 5;
       Session openSession = this.factory.openSession();
       Transaction tx= openSession.beginTransaction();
              openSession.update(del);
       tx.commit();
       openSession.close();
       return r;
    }
    public deliveryCharges getdeatilById(int id)
    {
       deliveryCharges user=null;
             String query ="from deliveryCharges where deliveryChargesId =:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e",id);
      
      user=(deliveryCharges) q.uniqueResult();
      
      session.close();
        
        return user;
    }
    
      public List<deliveryCharges> getCharges(){
    Session s = this.factory.openSession();
    Query q = s.createQuery("from deliveryCharges ");
    List<deliveryCharges> list =q.list();
    return list;
}
}
