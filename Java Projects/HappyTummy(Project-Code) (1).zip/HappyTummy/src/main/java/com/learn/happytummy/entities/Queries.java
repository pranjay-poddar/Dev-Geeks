/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Queries {
     @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
     private int queryId;
     
     
     public String SenderName;
     public String SenderEmail;
     public String Message;

    public Queries(int queryId, String SenderName, String SenderEmail, String Message) {
        this.queryId = queryId;
        this.SenderName = SenderName;
        this.SenderEmail = SenderEmail;
        this.Message = Message;
    }

    public Queries(String SenderName, String SenderEmail, String Message) {
        this.SenderName = SenderName;
        this.SenderEmail = SenderEmail;
        this.Message = Message;
    }

    public Queries() {
    }

    public int getQueryId() {
        return queryId;
    }

    public void setQueryId(int queryId) {
        this.queryId = queryId;
    }

    public String getSenderName() {
        return SenderName;
    }

    public void setSenderName(String SenderName) {
        this.SenderName = SenderName;
    }

    public String getSenderEmail() {
        return SenderEmail;
    }

    public void setSenderEmail(String SenderEmail) {
        this.SenderEmail = SenderEmail;
    }

    public String getMessage() {
        return Message;
    }

    public void setMessage(String Message) {
        this.Message = Message;
    }

    @Override
    public String toString() {
        return "Queries{" + "queryId=" + queryId + ", SenderName=" + SenderName + ", SenderEmail=" + SenderEmail + ", Message=" + Message + '}';
    }
     
     
     
}
