/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.Servlets;

import com.learn.happytummy.dao.UserDao;
import com.learn.happytummy.dao.deliveryChargesDao;
import com.learn.happytummy.dao.ordersDao;
import com.learn.happytummy.dao.restaurantDao;
import com.learn.happytummy.entities.Restaurant;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.entities.deliveryCharges;
import com.learn.happytummy.entities.orders;
import com.learn.happytummy.helper.FactoryProvider;
import java.io.IOException;

import static java.lang.System.out;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Aayush
 */
public class orderProcess extends HttpServlet {

    
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, AddressException, MessagingException {
        response.setContentType("text/html;charset=UTF-8");

        String ords = request.getParameter("ord");
        String ordType = request.getParameter("ordType");
        String ordType1 = request.getParameter("ordtype");
        if (ords.equalsIgnoreCase("orderReceived")) {

            deliveryChargesDao deo = new deliveryChargesDao(FactoryProvider.getFactory());
            deliveryCharges deliv = deo.getdeatilById(0);

//                                       
            String orderUserId1 = request.getParameter("CUST_ID");
            int orderUserId = Integer.parseInt(orderUserId1);
            String orderPaymentmode = request.getParameter("inlineRadioOptions");
            String orderAddress = request.getParameter("address");
            String orderuserphone = request.getParameter("phone");
            String orderuserName = request.getParameter("name");
           
//          int orderRestaurantId = Integer.parseInt(resid);
            String orderDeatils = "order details" + request.getParameter("details");
            String orderStatus = "unconfirmedByRestaurant";
            String total = request.getParameter("TXN_AMOUNT");
            
            int totalis = Integer.parseInt(total);
            HttpSession session = request.getSession();

            session.setAttribute("total amount", totalis + deliv.getDeliveryCharges());

            long totalamount = (long) session.getAttribute("total amount");

            DateFormat dform = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
            Date obj = new Date();
            out.println(dform.format(obj));
            String orderDate = dform.format(obj);

            orders ord = new orders();
            ord.setOrderUserId(orderUserId);

            ord.setOrderDate(orderDate);
            ord.setOrderAmount((int) totalamount);
            ord.setOrderDetails(orderDeatils);
            ord.setOrderPaymentMode(orderPaymentmode);
            ord.setOrderUserAddress(orderAddress);
            ord.setOrderUserphone(orderuserphone);
            ord.setOrderUserName(orderuserName);
            ord.setOrderStatus(orderStatus);
            ord.setOrderType(ordType);
             String orderRestaurantId = request.getParameter("resid");
             if(orderRestaurantId.equalsIgnoreCase("HT"))
             {
                 ord.setOrderRestaurantId("HT");
              
            ord.setOrderRestaurant("HT");

            ordersDao oDao = new ordersDao(FactoryProvider.getFactory());
            oDao.saveOrders(ord);

//            session.setAttribute("message", "Order Successfull Check Status in My orders!!!");

            response.sendRedirect("orderSuccess.jsp");
             return;
             }
             else{
                           ord.setOrderRestaurantId(orderRestaurantId);
             restaurantDao reslist = new restaurantDao(FactoryProvider.getFactory());
             
             int rid = Integer.parseInt(orderRestaurantId);
             
               Restaurant res = reslist.getRestaurantbyID(rid);
            ord.setOrderRestaurant(res.getRestaurantTitle());

            ordersDao oDao = new ordersDao(FactoryProvider.getFactory());
            oDao.saveOrders(ord);

//            session.setAttribute("message", "Order Successfull Check Status in My orders!!!");

            response.sendRedirect("orderSuccess.jsp");
             }
           

        }
      
else if (ords.equalsIgnoreCase("orderAcceptedandCooked")) {

            String orderid = request.getParameter("ordeid");
            int odid = Integer.parseInt(orderid);
            ordersDao odrdao = new ordersDao(FactoryProvider.getFactory());
            orders orde = odrdao.getOrdersForId(odid);
            ords = orde.getOrderStatus();
            
            

            if (ords.equalsIgnoreCase("unconfirmedByRestaurant")) {

                Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                orde.setOrderStatus("Order Accepted");
                hibernateSession.update(orde);

                tx.commit();
                
                hibernateSession.close();
                int uid =   orde.getOrderUserId();
                    UserDao ud = new UserDao(FactoryProvider.getFactory());
                    User usr = ud.getUserbyuid(uid);
                    String orderemail = usr.getUserEmail();
                  
                 final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
  // Get a Properties object    
                  Properties props = System.getProperties();
     props.setProperty("mail.smtp.host", "smtp.gmail.com");
     props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
     props.setProperty("mail.smtp.socketFactory.fallback", "false");
     props.setProperty("mail.smtp.port", "465");
     props.setProperty("mail.smtp.socketFactory.port", "465");
     props.put("mail.smtp.auth", "true");
     props.put("mail.debug", "true");
     props.put("mail.store.protocol", "pop3");
     props.put("mail.transport.protocol", "smtp");
     
                    javax.mail.Session session = javax.mail.Session.getInstance(props, new Authenticator() {

                        @Override
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication("happytummyjaora@gmail.com","htPass@123");
                        }
                    });

               // -- Create a new message --
     Message msg = new MimeMessage(session);

  // -- Set the FROM and TO fields --
     msg.setFrom(new InternetAddress("happytummyjaora@gmail.com"));
     msg.setRecipients(Message.RecipientType.TO, 
                      InternetAddress.parse(orderemail,false));
     msg.setSubject("Happy Tummy Jaora");
     msg.setText("Hi, "+orderemail+"\n Your order at "+orde.getOrderRestaurant()+" is accepted and Will Shortly deliver to you ");
                     

       
        
     msg.setSentDate(new Date());
     
     Transport.send(msg);
   
                        HttpSession httpsession = request.getSession();
                httpsession.setAttribute("message", "Order Acceptted Successfully");
                response.sendRedirect("restaurantOwnerHome.jsp");
                
                
            }
            
            
            else {
                HttpSession httpsession = request.getSession();
                httpsession.setAttribute("message", "Already Accepted");
                response.sendRedirect("restaurantOwnerHome.jsp");
            }

        } else if (ords.equalsIgnoreCase("Order Accepted")) {

            HttpSession httpsession = request.getSession();
            httpsession.setAttribute("message", "Already Accepted");
            response.sendRedirect("restaurantOwnerHome.jsp");
        } else if (ords.equalsIgnoreCase("Order Picked")) {

            String orderid = request.getParameter("ordeid");
            int odid = Integer.parseInt(orderid);
            ordersDao odrdao = new ordersDao(FactoryProvider.getFactory());

            orders orde = odrdao.getOrdersForId(odid);
            ords = orde.getOrderStatus();

            if (ords.equalsIgnoreCase("unconfirmedByRestaurant")) {

                HttpSession httpsession = request.getSession();
                httpsession.setAttribute("message", "Order Not Confirmed can not pick");
                response.sendRedirect("deliveryHome.jsp");
            }
                else if(ords.equalsIgnoreCase("Out For Delivery")) {

                HttpSession httpsession = request.getSession();
                httpsession.setAttribute("message", "Already Out For Delivery");
                response.sendRedirect("deliveryHome.jsp");
                        
            } else {
                Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                orde.setOrderStatus("Out For Delivery");
                hibernateSession.update(orde);

                tx.commit();
                hibernateSession.close();

                HttpSession httpsession = request.getSession();
                httpsession.setAttribute("message", "Order Picked Delivery in 35min!");
                response.sendRedirect("deliveryHome.jsp");
            }
        } 
          else if (ordType.equalsIgnoreCase("tiffin")) {
           
            String orderid = request.getParameter("ordeid");
            int odid = Integer.parseInt(orderid);
            ordersDao odrdao = new ordersDao(FactoryProvider.getFactory());

            orders orde = odrdao.getOrdersForId(odid);
           Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                orde.setOrderStatus("Order Accepted");
                hibernateSession.update(orde);

                tx.commit();
                hibernateSession.close();

                HttpSession httpsession = request.getSession();
                httpsession.setAttribute("message", "Order Accepted Successfully");
                response.sendRedirect("Admin_home.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (MessagingException ex) {
            Logger.getLogger(orderProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (MessagingException ex) {
            Logger.getLogger(orderProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
