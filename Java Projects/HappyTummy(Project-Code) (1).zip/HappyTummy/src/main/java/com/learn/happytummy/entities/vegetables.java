/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Aayush
 */

    
@Entity
public class vegetables {

        @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int vId;
    private String vName;
    private String vDesc;
    private String vPhoto;
    private int vPrice;

    public vegetables(int vId, String vName, String vDesc, String vPhoto, int vPrice) {
        this.vId = vId;
        this.vName = vName;
        this.vDesc = vDesc;
        this.vPhoto = vPhoto;
        this.vPrice = vPrice;
    }

    public vegetables() {
    }

    public vegetables(String vName, String vDesc, String vPhoto, int vPrice) {
        this.vName = vName;
        this.vDesc = vDesc;
        this.vPhoto = vPhoto;
        this.vPrice = vPrice;
    }

    public int getvId() {
        return vId;
    }

    public void setvId(int vId) {
        this.vId = vId;
    }

    public String getvName() {
        return vName;
    }

    public void setvName(String vName) {
        this.vName = vName;
    }

    public String getvDesc() {
        return vDesc;
    }

    public void setvDesc(String vDesc) {
        this.vDesc = vDesc;
    }

    public String getvPhoto() {
        return vPhoto;
    }

    public void setvPhoto(String vPhoto) {
        this.vPhoto = vPhoto;
    }

    public int getvPrice() {
        return vPrice;
    }

    public void setvPrice(int vPrice) {
        this.vPrice = vPrice;
    }

}
