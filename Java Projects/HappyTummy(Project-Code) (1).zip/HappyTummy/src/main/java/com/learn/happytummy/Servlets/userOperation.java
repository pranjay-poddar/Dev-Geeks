/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.Servlets;

import com.learn.happytummy.dao.UserDao;
import com.learn.happytummy.dao.deliveryChargesDao;
import com.learn.happytummy.dao.groceryDao;
import com.learn.happytummy.dao.restaurantDao;
import com.learn.happytummy.dao.tiffinDao;
import com.learn.happytummy.dao.vegetableDao;
import com.learn.happytummy.entities.Restaurant;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.entities.deliveryCharges;
import com.learn.happytummy.entities.grocery;
import com.learn.happytummy.entities.tiffin;
import com.learn.happytummy.entities.vegetables;
import com.learn.happytummy.helper.FactoryProvider;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Aayush
 */
public class userOperation extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String op =(String) request.getParameter("op");
//            String id2 = (String) request.getParameter("id1234");
 String id = request.getParameter("id123");
 String id2 = request.getParameter("id1234");
 String id12 = request.getParameter("id12345");
 
 
            if(op.equalsIgnoreCase("user")){
                 
           
           UserDao user = new UserDao(FactoryProvider.getFactory());
           User user1 = user.getUserbyEmail(id);
                   HttpSession httpsession = request.getSession();
 Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                hibernateSession.delete(user1);
                

                tx.commit();
                hibernateSession.close();
            httpsession.setAttribute("message", "User Removed ");
                response.sendRedirect("Admin_home.jsp");
            }
            else if (op.equalsIgnoreCase("Restaurant"))
            {
                restaurantDao res = new restaurantDao(FactoryProvider.getFactory());
         Restaurant restaurant = res.getRestaurantbyEmailID(id2);
          
 Session hibernateSession2 = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession2.beginTransaction();

//                hibernateSession.delete(res1);
                
hibernateSession2.delete(restaurant);
                tx.commit();
                hibernateSession2.close();
                                   HttpSession httpsession = request.getSession();

            httpsession.setAttribute("message", "Restaurant Removed ");
                response.sendRedirect("Admin_home.jsp");
            }
            else if (op.equalsIgnoreCase("Delivery"))
         { 
                        
           UserDao user = new UserDao(FactoryProvider.getFactory());
           User user1 = user.getUserbyEmail(id12);
                   HttpSession httpsession = request.getSession();
 Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                hibernateSession.delete(user1);
             tx.commit();
                hibernateSession.close();
            httpsession.setAttribute("message", "Delivery Boy Removed ");
                response.sendRedirect("Admin_home.jsp");

            }
            else if(op.equalsIgnoreCase("deliveryCharges"))
            {
                String charges = request.getParameter("charges");
                int chargeS = Integer.parseInt(charges);
                deliveryCharges deliv = new deliveryCharges();
                deliv.setDeliveryCharges(chargeS);
                deliveryChargesDao deo = new deliveryChargesDao(FactoryProvider.getFactory());
           int resId =     deo.saveCharges(deliv);
      HttpSession httpsession = request.getSession();

            httpsession.setAttribute("message", "Charges Updated ");
                response.sendRedirect("Admin_home.jsp");            
                
            }
            else if(op.equalsIgnoreCase("grocery"))
            {
                 String idgro1 = (String) request.getParameter("idgro");
int idgro = Integer.parseInt(idgro1);
groceryDao gdao = new groceryDao(FactoryProvider.getFactory());
grocery gro = gdao.getgroceryById(idgro);
          
 Session hibernateSession2 = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession2.beginTransaction();

//                hibernateSession.delete(res1);
                
              hibernateSession2.delete(gro);
                tx.commit();
                hibernateSession2.close();
                                   HttpSession httpsession = request.getSession();

            httpsession.setAttribute("message", "Grocery Removed ");
                response.sendRedirect("Admin_home.jsp");
            }
            else if(op.equalsIgnoreCase("tiffin"))
            {
                 String idgro1 = (String) request.getParameter("idtif");
int idgro = Integer.parseInt(idgro1);
tiffinDao tdao  = new tiffinDao(FactoryProvider.getFactory());
tiffin tf = tdao.gettiffinById(idgro);
          
 Session hibernateSession2 = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession2.beginTransaction();

//                hibernateSession.delete(res1);
                
              hibernateSession2.delete(tf);
                tx.commit();
                hibernateSession2.close();
                                   HttpSession httpsession = request.getSession();

            httpsession.setAttribute("message", "Tiffin Removed ");
                response.sendRedirect("Admin_home.jsp");
            }
         
            else if(op.equalsIgnoreCase("vegetables"))
            {
                 String idveg1 = (String) request.getParameter("idveg");
int idveg = Integer.parseInt(idveg1);
vegetableDao vdao = new vegetableDao(FactoryProvider.getFactory());
                vegetables veg = vdao.getvegetableById(idveg);
          
 Session hibernateSession2 = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession2.beginTransaction();

//                hibernateSession.delete(res1);
                
              hibernateSession2.delete(veg);
                tx.commit();
                hibernateSession2.close();
                                   HttpSession httpsession = request.getSession();

            httpsession.setAttribute("message", "Vegetable Removed ");
                response.sendRedirect("Admin_home.jsp");
            }
         
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
