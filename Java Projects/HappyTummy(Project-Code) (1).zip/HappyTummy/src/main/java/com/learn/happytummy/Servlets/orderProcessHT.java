/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.Servlets;

import com.learn.happytummy.dao.UserDao;
import com.learn.happytummy.dao.ordersDao;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.entities.orders;
import com.learn.happytummy.helper.FactoryProvider;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Aayush
 */
public class orderProcessHT extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, MessagingException {
        response.setContentType("text/html;charset=UTF-8");
            String ords = request.getParameter("ord");
//    
      
              if (ords.equalsIgnoreCase("orderAcceptedandCooked")) {
                   String orderid = request.getParameter("ordeid");
            int odid = Integer.parseInt(orderid);
            ordersDao odrdao = new ordersDao(FactoryProvider.getFactory());
            orders orde = odrdao.getOrdersForId(odid);
            ords = orde.getOrderStatus();
              if (ords.equalsIgnoreCase("unconfirmedByRestaurant")) {
                  
                     Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                orde.setOrderStatus("Order Accepted");
                hibernateSession.update(orde);

                tx.commit();
                hibernateSession.close();
                
                   int uid =   orde.getOrderUserId();
                    UserDao ud = new UserDao(FactoryProvider.getFactory());
                    User usr = ud.getUserbyuid(uid);
                    String orderemail = usr.getUserEmail();
                  
                 final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
  // Get a Properties object    
                  Properties props = System.getProperties();
     props.setProperty("mail.smtp.host", "smtp.gmail.com");
     props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
     props.setProperty("mail.smtp.socketFactory.fallback", "false");
     props.setProperty("mail.smtp.port", "465");
     props.setProperty("mail.smtp.socketFactory.port", "465");
     props.put("mail.smtp.auth", "true");
     props.put("mail.debug", "true");
     props.put("mail.store.protocol", "pop3");
     props.put("mail.transport.protocol", "smtp");
     
                    javax.mail.Session session = javax.mail.Session.getInstance(props, new Authenticator() {

                        @Override
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication("happytummyjaora@gmail.com","htPass@123");
                        }
                    });

               // -- Create a new message --
     Message msg = new MimeMessage(session);

  // -- Set the FROM and TO fields --
     msg.setFrom(new InternetAddress("happytummyjaora@gmail.com"));
     msg.setRecipients(Message.RecipientType.TO, 
                      InternetAddress.parse(orderemail,false));
     msg.setSubject("Happy Tummy Jaora");
     msg.setText("Hi, "+orderemail+"\n Your order at "+orde.getOrderRestaurant()+" is accepted and Will Shortly deliver to you ");
                     

       
        
     msg.setSentDate(new Date());
     
     Transport.send(msg);
   
                        HttpSession httpsession = request.getSession();
                httpsession.setAttribute("message", "Order Acceptted Successfully");
                response.sendRedirect("Admin_home.jsp");
                
                
                  
              }
              else {                        HttpSession httpsession = request.getSession();

                             httpsession.setAttribute("message", "Already Acceptted ");
                response.sendRedirect("Admin_home.jsp");
                
              }
            
                  
                  
              }
             
                 
              }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (MessagingException ex) {
            Logger.getLogger(orderProcessHT.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (MessagingException ex) {
            Logger.getLogger(orderProcessHT.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
