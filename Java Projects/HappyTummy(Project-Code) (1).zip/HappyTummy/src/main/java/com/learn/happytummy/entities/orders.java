/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 *
 * @author Aayush
 */
@Entity
public class orders {
    
   @Id
       @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int orderId;
   
   public String orderDetails;
   
   public String orderDate;
   
   public int orderAmount;
   
   public String orderStatus;

   public int orderUserId;
   public String orderUserName;
   public String orderUserphone;
   public String orderUserAddress;
   public String orderPaymentMode;
   public String orderRestaurant;
   public String orderRestaurantId;
   public String orderType;
   
   
    public orders() {
    }

    public orders(String orderDetails, String orderDate, int orderAmount, String orderStatus, int orderUserId, String orderUserName, String orderUserphone, String orderUserAddress, String orderPaymentMode) {
        this.orderDetails = orderDetails;
        this.orderDate = orderDate;
        this.orderAmount = orderAmount;
        this.orderStatus = orderStatus;
        this.orderUserId = orderUserId;
        this.orderUserName = orderUserName;
        this.orderUserphone = orderUserphone;
        this.orderUserAddress = orderUserAddress;
        this.orderPaymentMode = orderPaymentMode;
        
    }

    public orders(String orderDetails, String orderDate, int orderAmount, String orderStatus, int orderUserId, String orderUserName, String orderUserphone, String orderUserAddress, String orderPaymentMode, String orderRestaurant, String orderRestaurantId, String orderType) {
        this.orderDetails = orderDetails;
        this.orderDate = orderDate;
        this.orderAmount = orderAmount;
        this.orderStatus = orderStatus;
        this.orderUserId = orderUserId;
        this.orderUserName = orderUserName;
        this.orderUserphone = orderUserphone;
        this.orderUserAddress = orderUserAddress;
        this.orderPaymentMode = orderPaymentMode;
        this.orderRestaurant = orderRestaurant;
        this.orderRestaurantId = orderRestaurantId;
        this.orderType = orderType;
    }
    
    

    public int getOrderId() {
        return orderId;
    }

    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }

    public String getOrderDetails() {
        return orderDetails;
    }

    public String getOrderType() {
        return orderType;
    }

    public void setOrderType(String orderType) {
        this.orderType = orderType;
    }

    public void setOrderDetails(String orderDetails) {
        this.orderDetails = orderDetails;
    }

    public String getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(String orderDate) {
        this.orderDate = orderDate;
    }

    public int getOrderAmount() {
        return orderAmount;
    }

    public void setOrderAmount(int orderAmount) {
        this.orderAmount = orderAmount;
    }

   

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    public int getOrderUserId() {
        return orderUserId;
    }

    public void setOrderUserId(int orderUserId) {
        this.orderUserId = orderUserId;
    }

    public String getOrderRestaurant() {
        return orderRestaurant;
    }

    public void setOrderRestaurant(String orderRestaurant) {
        this.orderRestaurant = orderRestaurant;
    }

    public String getOrderRestaurantId() {
        return orderRestaurantId;
    }

    public void setOrderRestaurantId(String orderRestaurantId) {
        this.orderRestaurantId = orderRestaurantId;
    }

   

    public String getOrderUserName() {
        return orderUserName;
    }

    public void setOrderUserName(String orderUserName) {
        this.orderUserName = orderUserName;
    }

    public String getOrderUserphone() {
        return orderUserphone;
    }

    public void setOrderUserphone(String orderUserphone) {
        this.orderUserphone = orderUserphone;
    }

    public String getOrderUserAddress() {
        return orderUserAddress;
    }

    public void setOrderUserAddress(String orderUserAddress) {
        this.orderUserAddress = orderUserAddress;
    }

    public String getOrderPaymentMode() {
        return orderPaymentMode;
    }

    public void setOrderPaymentMode(String orderPaymentMode) {
        this.orderPaymentMode = orderPaymentMode;
    }

   
   
   
    
}
