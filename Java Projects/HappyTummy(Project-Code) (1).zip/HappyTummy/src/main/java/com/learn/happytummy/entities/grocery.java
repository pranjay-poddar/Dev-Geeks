
package com.learn.happytummy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class grocery {
        @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int gId;
    private String gName;
    private String gDesc;
    private String gPhoto;
    private int gPrice;

    public grocery() {
    }

    public grocery(int gId, String gName, String gDesc, String gPhoto, int gPrice) {
        this.gId = gId;
        this.gName = gName;
        this.gDesc = gDesc;
        this.gPhoto = gPhoto;
        this.gPrice = gPrice;
    }

    public int getgId() {
        return gId;
    }

    public void setgId(int gId) {
        this.gId = gId;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName;
    }

    public String getgDesc() {
        return gDesc;
    }

    public void setgDesc(String gDesc) {
        this.gDesc = gDesc;
    }

    public String getgPhoto() {
        return gPhoto;
    }

    public void setgPhoto(String gPhoto) {
        this.gPhoto = gPhoto;
    }

    public int getgPrice() {
        return gPrice;
    }

    public void setgPrice(int gPrice) {
        this.gPrice = gPrice;
    }
    
}
