
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.User;
import com.learn.happytummy.entities.deliveryCharges;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;


public class UserDao {
    
    
    private SessionFactory factory;
    public UserDao(SessionFactory factory){
    this.factory=factory;
}
//get email and password
    
    
public int saveCharges(User del)
    {
        int r = 5;
       Session openSession = this.factory.openSession();
       Transaction tx= openSession.beginTransaction();
              openSession.update(del);
       tx.commit();
       openSession.close();
       return r;
    }    
    
    public User getUserbyEmail(String Email)
    {
        User user=null;
             String query ="from User where userEmail=:e";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e", Email);
      
      user=(User) q.uniqueResult();
      
      session.close();
        
        return user;
    }
    public User getUserbyType(String UserType)
    {
        User user=null;
             String query ="from User where  userType=:u";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
           q.setParameter("u", UserType);
      
      user=(User) q.uniqueResult();
      
      session.close();
        
        return user;
    }
    public User getUserbyuid(int Userid)
    {
        User user=null;
             String query ="from User where  userId=:u";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
           q.setParameter("u", Userid);
      
      user=(User) q.uniqueResult();
      
      session.close();
        
        return user;
    }
    
    
    
     public User getUserbyPassword(String Password)
    {
        User user=null;
             String query ="from User where userPassword=:p";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("p", Password);
      
      user=(User) q.uniqueResult();
      
      session.close();
        
        return user;
    }
    
//    
    public User getUserbyEmailandPassword(String Email,String Password,String UserType){
       
        
        User user=null;
        
        {
         try {
            
            String query ="from User where userEmail=:e and userPassword=:p and userType=:u";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e", Email);
      q.setParameter("p", Password);
             
       q.setParameter("u", UserType);
      user=(User) q.uniqueResult();
      
      session.close();
         
         } catch (Exception e) {
            e.printStackTrace();
        }
       
       return user;
        }
       
    }
    
    
    
    
      public User getUserbyEmailandPassword(String Email,String Password){
       
        
        User user=null;
        
        {
         try {
            
            String query ="from User where userEmail=:e and userPassword=:p ";
      Session session =this.factory.openSession();
     Query q = session.createQuery(query);
      q.setParameter("e", Email);
      q.setParameter("p", Password);
             
      user=(User) q.uniqueResult();
      
      session.close();
         
         } catch (Exception e) {
            e.printStackTrace();
        }
       
       return user;
        }
        
      
      }
      
       public List<User> getlistofUsers()
        {
        Session s = this.factory.openSession();
        Query q = s.createQuery("from User");
        List<User> list = q.list();
        return list;
        }
       public List<User> getlistofUsersDelivery(String userType)
        {
                    User user=null;

        Session s1 = this.factory.openSession();
                    String query ="from User where userType=:e1";
     Query q = s1.createQuery(query);

                           q.setParameter("e1", userType);
                           
        List<User> list = q.list();

        s1.close();
//              user=(User) q.uniqueResult();
//


        
        return list;
        }
         public List<User> getlistofinActiveUser()
        {
            String query ="from User where userStatus= :e and userType =:p";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
               

      q.setParameter("e","inactive");
      q.setParameter("p","Delivery Boy");
      
        List<User> listres = q.list();
        return listres;
        }
}


