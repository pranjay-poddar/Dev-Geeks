/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.helper;

import java.util.HashMap;
import java.util.Map;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

/**
 *
 * @author Aayush
 */
public class Count {
    
    
    public static Map<String,Long> getCount(SessionFactory factory)
    {
        Session session =  factory.openSession();
        String q1= "Select count(*) from User";
        String q2= "Select count(*) from User Where userType=:e";
        String q3= "Select count(*) from Restaurant";
        String q4= "Select count(*) from grocery";
        String q5= "Select count(*) from vegetables";
        
        
        Query query1 = session.createQuery(q1);

        Query query2 = session.createQuery(q2);
                 query2.setParameter("e", "Delivery Boy");

        Query query3 = session.createQuery(q3);
        Query query4 = session.createQuery(q4);
        Query query5 = session.createQuery(q5);
        
        
        Long userLong =(Long)query1.list().get(0);
        Long userLong2 =(Long)query2.list().get(0);
        Long userLong3 =(Long)query3.list().get(0);
        Long userLong4 =(Long)query4.list().get(0);
        Long userLong5 =(Long)query5.list().get(0);
        
        Map<String,Long> map = new HashMap<>();
        
        map.put("userCount", userLong);
        map.put("deliCount", userLong2);
        map.put("restaurantCount", userLong3);
        map.put("groceryCount", userLong4);
        map.put("vegetableCount", userLong5);
        
        session.close();
        return map;
    }
}
