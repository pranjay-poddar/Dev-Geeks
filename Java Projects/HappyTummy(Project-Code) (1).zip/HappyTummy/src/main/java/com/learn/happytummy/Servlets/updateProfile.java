/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.Servlets;

import com.learn.happytummy.dao.UserDao;
import com.learn.happytummy.dao.deliveryChargesDao;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.entities.deliveryCharges;
import com.learn.happytummy.helper.FactoryProvider;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Aayush
 */
public class updateProfile extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
       String uName = request.getParameter("uName");
       String uPhone = request.getParameter("uPhone");
       String uPassword = request.getParameter("uPass");
       String uEmail = request.getParameter("uEmail");
       String u = request.getParameter("op");
               UserDao user = new UserDao(FactoryProvider.getFactory());
           User user1 = user.getUserbyEmail(uEmail);
        user1.setUsername(uName);
        user1.setUserPhone(uPhone);
        user1.setUserPassword(uPassword);
        user.saveCharges(user1);
        

      HttpSession httpsession = request.getSession();

       
                   
       switch (u)
       {
           
           case "res":
                response.sendRedirect("restaurantOwnerHome.jsp");
                     httpsession.setAttribute("message", "Profile Updated ");
               break;
           case "del":
                response.sendRedirect("deliveryHome.jsp");
                     httpsession.setAttribute("message", "Profile Updated ");
               break;
           case "nor":
                response.sendRedirect("login_page.jsp");
                     httpsession.setAttribute("message", "Profile Updated Log-in Again!! ");
               break;
               
               
               
       }
       


                
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
