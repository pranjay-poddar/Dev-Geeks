/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.dao;

import com.learn.happytummy.entities.Restaurant;
import com.learn.happytummy.entities.tableReservation;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;

/**
 *
 * @author Aayush
 */
public class tableDao {
    
    private SessionFactory factory;

    public tableDao(SessionFactory factory) {
        this.factory = factory;
    }
    
    
     public List<tableReservation> gettables(int resid){
         
     tableReservation order = null;
        String query = "from tableReservation where resid =:e ";
        Session session = this.factory.openSession();
        Query q = session.createQuery(query);
        q.setParameter("e", resid);

        List<tableReservation> list = q.list();

        session.close();

        return list;
}
    
}
