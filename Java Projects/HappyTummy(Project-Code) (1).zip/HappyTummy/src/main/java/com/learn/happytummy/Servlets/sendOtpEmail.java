/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.Servlets;

import com.learn.happytummy.ForgetPassword.checkUserEmail;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Properties;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Aayush
 */
public class sendOtpEmail extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            try {
                String email = request.getParameter("email");

                if (checkUserEmail.validateUserEmail(email)) {
                    
                    int randomPin = (int) (Math.random() * 900000) + 100000;
                    String otp = String.valueOf(randomPin);

                    HttpSession session2 = request.getSession();
                    session2.setAttribute("otp", otp);
                    session2.setAttribute("email", email);
                    
                    
                  
                 final String SSL_FACTORY = "javax.net.ssl.SSLSocketFactory";
  // Get a Properties object    
                  Properties props = System.getProperties();
     props.setProperty("mail.smtp.host", "smtp.gmail.com");
     props.setProperty("mail.smtp.socketFactory.class", SSL_FACTORY);
     props.setProperty("mail.smtp.socketFactory.fallback", "false");
     props.setProperty("mail.smtp.port", "465");
     props.setProperty("mail.smtp.socketFactory.port", "465");
     props.put("mail.smtp.auth", "true");
     props.put("mail.debug", "true");
     props.put("mail.store.protocol", "pop3");
     props.put("mail.transport.protocol", "smtp");
     
                    Session session = Session.getInstance(props, new Authenticator() {

                        @Override
                        protected PasswordAuthentication getPasswordAuthentication() {
                            return new PasswordAuthentication("happytummyjaora@gmail.com","htPass@123");
                        }
                    });

               // -- Create a new message --
     Message msg = new MimeMessage(session);

  // -- Set the FROM and TO fields --
     msg.setFrom(new InternetAddress("happytummyjaora@gmail.com"));
     msg.setRecipients(Message.RecipientType.TO, 
                      InternetAddress.parse(email,false));
     msg.setSubject("Happy Tummy Jaora");
     msg.setText("Hi, "+email+"\n Your Request for Forgot Password "
             + " OTP IS: "+otp);
                         session2.setAttribute("message", "OTP Send");

        RequestDispatcher rd=request.getRequestDispatcher("enterOtp.jsp");  
        
        rd.forward(request,response);  
        
     msg.setSentDate(new Date());
     
     Transport.send(msg);
     System.out.println("Message sent.");  
//                 
                } else {
                    
                    
                      HttpSession session21 = request.getSession();
                    session21.setAttribute("message", "No such E-mail Exists");
                    
 RequestDispatcher rd=request.getRequestDispatcher("forgetPassword.jsp");  
        
        rd.forward(request,response); 
                }

            } catch (Exception e) {
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
