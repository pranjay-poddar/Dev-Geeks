/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.Servlets;

import com.learn.happytummy.dao.UserDao;
import com.learn.happytummy.dao.restaurantDao;
import com.learn.happytummy.entities.Restaurant;
import com.learn.happytummy.entities.User;
import com.learn.happytummy.helper.FactoryProvider;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Aayush
 */
public class requestOperation extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String op = request.getParameter("op");
            String resName = request.getParameter("resTitle");
            String resEmail = request.getParameter("resEmail");
            String resDescription = request.getParameter("resDesc");
            String resAddress = request.getParameter("resAdd");
            String resImg0 = request.getParameter("resImg0");
            String resImg1 = request.getParameter("resImg1");
            String resImg2 = request.getParameter("resImg2");
            String resImg3 = request.getParameter("resImg3");
            if ("request".equals(op)) {

                String resStatus = "inactive";

                restaurantDao res = new restaurantDao(FactoryProvider.getFactory());
                Restaurant restaurant = new Restaurant(resName, resDescription, resEmail, resAddress,resImg0, resImg1, resImg2, resImg3, resStatus);
//                Restaurant restaurant = new Restaurant(resName, resDescription, resEmail, resAddress, resImg1, resImg2, resImg3, resStatus);
//            Restaurant rest = new Restaurant(resName,resEmail,resDescription,resAddress,resImg1,resImg2,resImg3,resStatus);
//            
//            Restaurant restaurant = new Restaurant(resEmail, resDescription, resEmail, resAddress, resImg1, resImg2, resImg3, resStatus);
                Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                int resId = (int) hibernateSession.save(restaurant);
                tx.commit();
                                hibernateSession.close();
 HttpSession httpsession = request.getSession();

                httpsession.setAttribute("message", "Request Send. Kindly check E-mail for response");
                                response.sendRedirect("restaurantOwnerHome.jsp");


                return;
            } else if(op.equalsIgnoreCase("apres")) {
                            String emailid = request.getParameter("resEmail");
                            String emailid2 = request.getParameter("email");

                UserDao userdao1 = new UserDao(FactoryProvider.getFactory());
                User ser = userdao1.getUserbyEmail(emailid2);
                restaurantDao res = new restaurantDao(FactoryProvider.getFactory());
                Restaurant rest = res.getRestaurantbyEmailID(emailid2);

                Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                rest.setRestaurantStatus("active");
                ser.setUserStatus("active");
                hibernateSession.update(rest);
                hibernateSession.update(ser);
                
                

                tx.commit();

                hibernateSession.close();
                                HttpSession httpsession = request.getSession();

                                httpsession.setAttribute("message", "Request Approved . Restaurant Added");
                                response.sendRedirect("Admin_home.jsp");

                return;

            }
            
        else if( op.equalsIgnoreCase("apdel") ) {
                            String emailid = request.getParameter("email");
                       

                UserDao userdao1 = new UserDao(FactoryProvider.getFactory());
                User ser = userdao1.getUserbyEmail(emailid);
     

                Session hibernateSession = FactoryProvider.getFactory().openSession();

                Transaction tx = hibernateSession.beginTransaction();

                
                ser.setUserStatus("active");
     
                hibernateSession.update(ser);
                
                

                tx.commit();

                hibernateSession.close();
                                HttpSession httpsession = request.getSession();

                                httpsession.setAttribute("message", "Delivery Boy Account Activated");
                                response.sendRedirect("Admin_home.jsp");

                return;

            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
