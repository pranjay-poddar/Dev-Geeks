
package com.learn.happytummy.entities;

import java.util.ArrayList;
import java.util.List;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Restaurant {
        @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int restaurantId;
        
    private String restaurantTitle;
    private String restaurantDescription;
    private String restaurantEmail;
    private String restaurantAddress;
    private String restaurantImg0;
    private String restaurantImg1;
    private String restaurantImg2;
    private String restaurantImg3;
    private String restaurantStatus;

    
    @OneToMany(mappedBy ="restaurantID")
    private List<Category> categorys=new ArrayList<>();
     
    @OneToMany(mappedBy ="restaurantID")
    private List<Product> product=new ArrayList<>();
    


    
    public Restaurant(String restaurantTitle, String restaurantDescription, String restaurantEmail, String restaurantAddress, String restaurantImg0, String restaurantImg1, String restaurantImg2, String restaurantImg3, String restaurantStatus) {
        this.restaurantTitle = restaurantTitle;
        this.restaurantDescription = restaurantDescription;
        this.restaurantEmail = restaurantEmail;
        this.restaurantAddress = restaurantAddress;
        this.restaurantImg0 = restaurantImg0;
        this.restaurantImg1 = restaurantImg1;
        this.restaurantImg2 = restaurantImg2;
        this.restaurantImg3 = restaurantImg3;
        this.restaurantStatus = restaurantStatus;
    }

    public Restaurant(String restaurantTitle, String restaurantDescription, String restaurantEmail, String restaurantAddress, String restaurantImg1, String restaurantImg2, String restaurantImg3, String restaurantStatus) {
        this.restaurantTitle = restaurantTitle;
        this.restaurantDescription = restaurantDescription;
        this.restaurantEmail = restaurantEmail;
        this.restaurantAddress = restaurantAddress;
        this.restaurantImg1 = restaurantImg1;
        this.restaurantImg2 = restaurantImg2;
        this.restaurantImg3 = restaurantImg3;
        this.restaurantStatus = restaurantStatus;
    }

  

  
    public Restaurant() {
    }

   

    public String getRestaurantStatus() {
        return restaurantStatus;
    }

    public void setRestaurantStatus(String restaurantStatus) {
        this.restaurantStatus = restaurantStatus;
    }

    public String getRestaurantImg0() {
        return restaurantImg0;
    }

    public void setRestaurantImg0(String restaurantImg0) {
        this.restaurantImg0 = restaurantImg0;
    }

   

    public String getRestaurantAddress() {
        return restaurantAddress;
    }

    public void setRestaurantAddress(String restaurantAddress) {
        this.restaurantAddress = restaurantAddress;
    }

    public String getRestaurantImg1() {
        return restaurantImg1;
    }

    public void setRestaurantImg1(String restaurantImg1) {
        this.restaurantImg1 = restaurantImg1;
    }

    public String getRestaurantImg2() {
        return restaurantImg2;
    }

    public void setRestaurantImg2(String restaurantImg2) {
        this.restaurantImg2 = restaurantImg2;
    }

    public String getRestaurantImg3() {
        return restaurantImg3;
    }

    public void setRestaurantImg3(String restaurantImg3) {
        this.restaurantImg3 = restaurantImg3;
    }

   
   

    public int getRestaurantId() {
        return restaurantId;
    }

    public void setRestaurantId(int restaurantId) {
        this.restaurantId = restaurantId;
    }

    public String getRestaurantTitle() {
        return restaurantTitle;
    }

    public void setRestaurantTitle(String restaurantTitle) {
        this.restaurantTitle = restaurantTitle;
    }

    public String getRestaurantDescription() {
        return restaurantDescription;
    }

    public void setRestaurantDescription(String restaurantDescription) {
        this.restaurantDescription = restaurantDescription;
    }

    public List<Category> getCategorys() {
        return categorys;
    }

    public void setCategorys(List<Category> categorys) {
        this.categorys = categorys;
    }

    public List<Product> getProduct() {
        return product;
    }

    public void setProduct(List<Product> product) {
        this.product = product;
    }

    public String getRestaurantEmail() {
        return restaurantEmail;
    }

    public void setRestaurantEmail(String restaurantEmail) {
        this.restaurantEmail = restaurantEmail;
    }

  
   

    

   
}
