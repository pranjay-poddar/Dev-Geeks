/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.learn.happytummy.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity    
public class deliveryCharges {
    @Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
     private int deliveryChargesId;
    private long deliveryCharges;

    public deliveryCharges(long deliveryCharges) {
        this.deliveryCharges = deliveryCharges;
    }

    public int getDeliveryChargesId() {
        return deliveryChargesId;
    }

    public void setDeliveryChargesId(int deliveryChargesId) {
        this.deliveryChargesId = deliveryChargesId;
    }

    public long getDeliveryCharges() {
        return deliveryCharges;
    }

    public void setDeliveryCharges(long deliveryCharges) {
        this.deliveryCharges = deliveryCharges;
    }

    public deliveryCharges() {
    }
    
    
}
